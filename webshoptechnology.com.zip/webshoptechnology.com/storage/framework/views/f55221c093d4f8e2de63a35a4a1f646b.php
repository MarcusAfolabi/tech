<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['blog']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['blog']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<section class="blog__area-4 blog__animation">
    <div class="container g-0 line_4 pt-150 pb-150">
        <div class="line-col-4">
            <div></div>
            <div></div>
            <div></div>
            <div></div>
        </div>

        <div class="row">
            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-4">
                <div class="sec-title-wrapper text-anim">
                    <h2 class="sec-subtile-6">Recent Blog</h2>
                    <h3 class="sec-title-6 title-anim">Updated <br> Journal</h3>
                    <p>We help brands stand out through aweful, elegant visual design. Our design mainly philosophy.</p>
                    <a class="btn-started" href="#">All Articles <span><i class="fa-solid fa-arrow-right"></i></span></a>
                </div>
            </div>
            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-4">
                <article class="blog__item-4">
                    <div class="blog__img-4">
                        <a href="blog-details.html">
                            <img src="assets/imgs/blog/4/1.jpg" alt="Blog Image">
                        </a>
                    </div>
                    <h4 class="blog__meta-4"><a href="category.html">UI Design</a> <span>02 May 2019</span></h4>
                    <h5><a href="blog-details.html" class="blog__title-4">Ways of lying to yourself about your new
                            relationship.</a></h5>
                    <a href="blog-details.html" class="blog__btn-4">Read More <span><i class="fa-solid fa-arrow-right"></i></span></a>
                </article>
            </div>

            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-4">
                <article class="blog__item-4">
                    <div class="blog__img-4">
                        <a href="blog-details.html">
                            <img src="assets/imgs/blog/4/2.jpg" alt="Blog Image">
                        </a>
                    </div>
                    <h4 class="blog__meta-4"><a href="category.html">UX Design</a> <span>02 May 2019</span></h4>
                    <h5><a href="blog-details.html" class="blog__title-4">Ways of lying to yourself about your new
                            relationship.</a></h5>
                    <a href="blog-details.html" class="blog__btn-4">Read More <span><i class="fa-solid fa-arrow-right"></i></span></a>
                </article>
            </div>
        </div>
    </div>
</section><?php /**PATH /home/nzfdwqne/webshoptechnology.com/resources/views/components/blog.blade.php ENDPATH**/ ?>