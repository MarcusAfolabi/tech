<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['approach']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['approach']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<section class="solution__area-4">
    <div class="container">
        <div class="row">
            <div class="col-xxl-5 offset-xxl-7 col-xl-5 offset-xl-7 col-lg-6 offset-lg-6 col-md-6 offset-md-6">
                <div class="solution__content">
                    <h2 class="sec-subtile-6">Our Approach </h2>
                    <h3 class="sec-title-6 title-anim">We take a customized <br>approach to each client's problem, </h3>
                    <ul class="solution__list title-anim">
                        <li>Consultation and Needs Assessment</li>
                        <li>Customized Solutions</li>
                        <li>Collaboration and Communication</li>
                        <li>Agile Development</li>
                        <li>Testing and Quality Assurance</li>
                        <li>Follow-up and Support</li>
                        <li>Continuous Improvement</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section><?php /**PATH /home/nzfdwqne/webshoptechnology.com/resources/views/components/approach.blade.php ENDPATH**/ ?>