<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['feat']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['feat']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<section class="feature__area-6">
    <div class="container line_4">
        <div class="line-col-4">
            <div></div>
            <div></div>
            <div></div>
            <div></div>
        </div>

        <div class="row">
            <div class="col-xxl-5 col-xl-5 col-lg-5 col-md-6">
                <div class="feature__content-left">
                    <h2 class="sec-subtile-6">Features</h2>
                    <h3 class="sec-title-6 title-anim">features that <br>make us stand <br>out </h3>
                </div>
            </div>
            <div class="col-xxl-7 col-xl-7 col-lg-7 col-md-6">
                <div class="feature__content-right">
                    <h4 class="feature__title-6">Customization</h4>
                    <h4 class="feature__title-6">User-Friendly Design</h4>
                    <h4 class="feature__title-6">Responsive Design</h4>
                    <h4 class="feature__title-6">SEO Optimization</h4>
                    <h4 class="feature__title-6">E-commerce Capabilities</h4>
                    <h4 class="feature__title-6">Analytics and Reporting</h4>
                    <h4 class="feature__title-6">Ongoing Support</h4>
                    <p>These features are designed to help our clients achieve their online goals and </span> stay ahead of the competition.</p>
                    <img class="feature__img-1" src="<?php echo e(asset('assets/imgs/feature/4/1.png')); ?>" alt="Icon">
                    <img class="feature__img-2" src="<?php echo e(asset('assets/imgs/feature/4/2.png')); ?>" alt="Icon">
                    <img class="feature__img-3" src="<?php echo e(asset('assets/imgs/feature/4/3.png')); ?>" alt="Icon">
                </div>
            </div>
            <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6">
                <div class="feature__content">
                    <img src="<?php echo e(asset('assets/imgs/feature/4/feature.jpg')); ?>" alt="Features Image">
                </div>
            </div>

        </div>
    </div>
</section><?php /**PATH /home/nzfdwqne/webshoptechnology.com/resources/views/components/feature.blade.php ENDPATH**/ ?>