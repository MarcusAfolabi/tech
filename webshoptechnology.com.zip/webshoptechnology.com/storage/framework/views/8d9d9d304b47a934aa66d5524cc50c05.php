<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['create']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['create']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<form action="#">
    <div class="uk-switcher lg:flex lg:flex-col justify-between lg:h-full" id="form-type">
        <div class="line">
            <input class="line__input" id="product_name" autocomplete="off" name="product_name" type="text" onkeyup="this.setAttribute('value', this.value);" value="<?php echo e(old('product_name')); ?>">
            <span for="product_name" class="line__placeholder"> Product Name </span>
        </div>
        <div>
            <textarea maxlength="500" class="with-border px-3 py-3" placeholder="A product description is the short marketing words that explains what a product is 
                    and why it's worth purchasing. " name="short_description" value=""><?php echo e(old('short_description')); ?></textarea>
        </div>
</form><?php /**PATH /home/nzfdwqne/webshoptechnology.com/resources/views/components/create-blog.blade.php ENDPATH**/ ?>