<?php $__env->startSection('title', ' Public Relations (PR) services'); ?>
<?php $__env->startSection('description', "To help businesses effectively manage their public image, enhance their reputation, and build stronger relationships with their stakeholders"); ?>
<?php $__env->startSection('keywords', 'seller, buyers, buy, sell, jiji, konga, jumia, vendor, shopify, wix, woocommerce, plugins, extension, team, extensive, experience, creating, high-quality, user-friendly, websites, mobile, mobile apps, apps, fiverr, upwork, brand, webshop, software, engineering, frontend, backend, design, development, craft, game, web, website, technology'); ?>
<?php $__env->startSection('canonical', 'https://webshoptechnology.com/services/public-relations-service'); ?>
<?php $__env->startSection('main'); ?>
<main>
    <section class="development__area">
        <div class="container g-0 line pt-130 pb-150">
            <div class="line-3"></div>
            <div class="row">
                <div class="col-xxl-5 col-xl-5 col-lg-5 col-md-5">
                    <div class="sec-title-wrapper">
                        <h2 class="sec-title animation__char_come"> Public Relations (PR) services</h2>
                    </div>
                </div>
                <div class="col-xxl-7 col-xl-7 col-lg-7 col-md-7">
                    <div class="development__wrapper">
                        <div class="development__content">
                            <p>To help businesses effectively manage their public image, </p>
                            <p>enhance their reputation, and build stronger relationships with their stakeholders</p>
                        </div>
                        <ul>
                            <li>+ PR software</li>
                            <li>+ Media monitoring tools </li>
                            <li>+ Social media management tools</li>
                            <li>+ Analytics software</li>
                        </ul>
                    </div>
                </div>
                <div class="col-xxl-8 col-xl-8 col-lg-8 col-md-8">
                    <div class="development__img">
                        <img src="<?php echo e(asset('assets/imgs/thumb/dev-1.jpg')); ?>" alt="Development Image" data-speed="auto">
                    </div>
                </div>
                <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-4">
                    <div class="development__img">
                        <img src="<?php echo e(asset('assets/imgs/thumb/dev-2.jpg')); ?>" alt="Development Image">
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="workflow__area-6">
        <div class="container g-0 line pb-130">
            <div class="line-3"></div>
            <div class="workflow__wrapper-6">
                <div class="row">
                    <div class="col-xxl-3 col-xl-3 col-lg-3 col-md-3">
                        <div class="workflow__slide-6">
                            <h6 class="workflow__title-6">Analytics and Reporting</h6>
                            <p>We provide regular analytics and reporting on the effectiveness of our PR campaigns, which helps clients to track their ROI and make informed decisions.
                            </p>
                        </div>
                    </div>

                    <div class="col-xxl-3 col-xl-3 col-lg-3 col-md-3">
                        <div class="workflow__slide-6">
                            <h6 class="workflow__title-6">Social Media Management</h6>
                            <p>We assist clients in managing their social media presence and engagement with their audience. We help clients to create compelling content, build followership, and engage with their audience on different social media platforms.</p>
                        </div>
                    </div>

                    <div class="col-xxl-3 col-xl-3 col-lg-3 col-md-3">
                        <div class="workflow__slide-6">
                            <h6 class="workflow__title-6">Crisis Management</h6>
                            <p>We offer crisis management services to help clients navigate challenging situations and protect their reputation. This includes developing crisis communications plans, managing media inquiries, and implementing effective messaging strategies.</p>
                        </div>
                    </div>
                    <div class="col-xxl-3 col-xl-3 col-lg-3 col-md-3">
                        <div class="workflow__slide-6">
                            <h6 class="workflow__title-6">Media Relations</h6>
                            <p>We help clients to build positive relationships with the media by identifying relevant journalists and publications, crafting targeted pitches, and facilitating interviews and coverage.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="service__detail">
        <div class="container g-0 line pb-140">
            <div class="line-3"></div>
            <div class="row">
                <div class="col-xxl-12">
                    <div class="sec-title-wrapper">
                        <h2 class="sec-title title-anim">We team-up, we collaborate and solve problems together</h2>
                    </div>
                </div>
                <div class="col-xxl-3 col-xl-3 col-lg-3 col-md-3">
                    <div class="service__detail-circle">
                        <span></span>
                    </div>
                </div>
                <div class="col-xxl-9 col-xl-9 col-lg-9 col-md-9">
                    <div class="service__detail-img">
                        <img src="<?php echo e(asset('assets/imgs/thumb/service-detail.png')); ?>" alt="Service detail image">
                        <img src="<?php echo e(asset('assets/imgs/icon/shape-6.png')); ?>" alt="Service shape image" class="sd-shape">
                    </div>
                    <div class="service__detail-content">
                        <p>Our team works closely with clients to develop a customized PR strategy that aligns with their goals, objectives, and values </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="faq__area">
        <div class="container g-0 line pb-140">
            <div class="line-3"></div>
            <div class="row">
                <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6">
                    <div class="faq__img">
                    <img src="<?php echo e(asset('assets/imgs/thumb/faq.png')); ?>" alt="FAQ Image" data-speed="auto">
                    </div>
                </div>
                <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6">
                    <div class="faq__content">
                        <h2 class="faq__title title-anim">Answers to possible questions</h2>

                        <div class="faq__list">
                            <div class="accordion" id="accordionExample">
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="headingOne">
                                        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                        What agency do you partner with to offer PR services?</button>
                                    </h2>
                                    <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                                        <div class="accordion-body">
                                            <p> Webshop Tech partners with a reputable PR agency that has a proven track record of delivering high-quality PR services to clients across different industries.</p>
                                        </div>
                                    </div>
                                </div>

                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="headingTwo">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                        How do you ensure that the PR services you offer align with my business goals and values? </button>

                                    </h2>
                                    <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
                                        <div class="accordion-body">
                                            <p> Our PR partner works closely with our team to develop a customized PR strategy that aligns with your business goals, objectives, and values. We also maintain regular communication with you to ensure that our PR efforts are in line with your expectations.

                                               
                                        </div>
                                    </div>
                                </div>

                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="headingThree">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                        How do you measure the success of your PR campaigns? </button>
                                    </h2>
                                    <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionExample">
                                        <div class="accordion-body">
                                            <p>  Our PR partner uses a variety of tools and metrics to measure the success of our PR campaigns, including media placements, social media engagement, website traffic, and other key performance indicators (KPIs). We provide regular analytics and reporting on the effectiveness of our PR campaigns.

                                               </p>
                                        </div>
                                    </div>
                                </div>

                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="headingFour">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                        How do you handle crisis management for clients?  </button>
                                    </h2>
                                    <div id="collapseFour" class="accordion-collapse collapse" aria-labelledby="headingFour" data-bs-parent="#accordionExample">
                                        <div class="accordion-body">
                                            <p>  Our PR partner has extensive experience in crisis management and works closely with clients to develop effective crisis communications plans that can help mitigate the impact of negative events. We also provide 24/7 support to clients during crises and work to implement messaging strategies that can help protect their reputation.
 </p>
                                        </div>
                                    </div>
                                </div>

                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="headingFive">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
                                        How do you ensure that my business receives personalized attention and support?</button>
                                    </h2>
                                    <div id="collapseFive" class="accordion-collapse collapse" aria-labelledby="headingFive" data-bs-parent="#accordionExample">
                                        <div class="accordion-body">
                                            <p>Our PR partner is committed to delivering personalized attention and support to each client we work with. We maintain regular communication with you, assign dedicated account managers to each project, and work to build strong relationships with our clients to ensure their satisfaction.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- FAQ area end -->

    <?php if (isset($component)) { $__componentOriginalb491a1d1f2d70210a6502f87c9c5a799 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb491a1d1f2d70210a6502f87c9c5a799 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.cta2','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('cta2'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb491a1d1f2d70210a6502f87c9c5a799)): ?>
<?php $attributes = $__attributesOriginalb491a1d1f2d70210a6502f87c9c5a799; ?>
<?php unset($__attributesOriginalb491a1d1f2d70210a6502f87c9c5a799); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb491a1d1f2d70210a6502f87c9c5a799)): ?>
<?php $component = $__componentOriginalb491a1d1f2d70210a6502f87c9c5a799; ?>
<?php unset($__componentOriginalb491a1d1f2d70210a6502f87c9c5a799); ?>
<?php endif; ?>
</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nzfdwqne/webshoptechnology.com/resources/views/services/publicRelations.blade.php ENDPATH**/ ?>