<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['work']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['work']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<section class="workflow__area-4">
    <div class="container line_4 pt-100 pb-130">
        <div class="line-col-4">
            <div></div>
            <div></div>
            <div></div>
            <div></div>
        </div>

        <div class="row animation_workflow_6">
            <div class="col-xxl-12">
                <div class="title-wrapper-6 text-anim">
                    <h2 class="sec-subtile-6">Our Workflow</h2>
                    <h3 class="sec-title-6 title-anim">Research and Analysis</h3>
                    <p>We gather information about your business, target audience, goals, and current challenges. </p>
                </div>
            </div>
            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-4">
                <div class="workflow__item-4">
                    <img src="<?php echo e(asset('assets/imgs/thumb/1.png')); ?>" alt="Work Image">
                    <h4 class="workflow__title-4">Design and Development</h4>
                    <p>We follow a rigorous development process, including coding, testing, and quality assurance, to ensure that the end product is of the highest quality.</p>
                </div>
            </div>
            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-4">
                <div class="workflow__item-4">
                    <img src="<?php echo e(asset('assets/imgs/thumb/2.png')); ?>" alt="Work Image">
                    <h4 class="workflow__title-4">Project Management</h4>
                    <p> Our project managers ensure that the project is progressing according to schedule, that all stakeholders are informed of progress, and that any issues are addressed promptly.</p>
                </div>
            </div>
            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-4">
                <div class="workflow__item-4">
                    <img src="<?php echo e(asset('assets/imgs/thumb/3.png')); ?>" alt="Work Image">
                    <h4 class="workflow__title-4">Maintenance and Support</h4>
                    <p>We offer various maintenance and support plans tailored to our clients' needs, which can include security updates, bug fixes, and new feature development. </p>
                </div>
            </div>
        </div>
    </div>
</section><?php /**PATH /home/nzfdwqne/webshoptechnology.com/resources/views/components/workflow.blade.php ENDPATH**/ ?>