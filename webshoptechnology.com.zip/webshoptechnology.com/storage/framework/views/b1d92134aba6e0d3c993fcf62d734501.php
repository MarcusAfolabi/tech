<?php $__env->startSection('title', '500 - Connection Problem!'); ?>
<?php $__env->startSection('main'); ?>

<body class="error-page">
    <div class="main-wrapper">
        <div class="error-box">
            <h1>503</h1>
            <h3 class="h2 mb-3"><i class="fas fa-exclamation-circle"></i><?php echo $__env->yieldContent('title'); ?></h3>
            <p class="h4 font-weight-normal">Poor internet connection. Please try again with strong internet connection. Thank you</p>
            <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-primary">Back to Dashboard</a>
        </div>
    </div>
</body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nzfdwqne/webshoptechnology.com/resources/views/errors/network.blade.php ENDPATH**/ ?>