<?php $__env->startSection('title', 'Thank you so much'); ?>
<?php $__env->startSection('description', 'Your payment has been confirmed and a receipt has been sent to your mail'); ?>
<?php $__env->startSection('keywords', 'ui/ux, thanks, payment system, flutterwave, paystack, monnify, payment gateway, frontend, product designer, identity, marketing, channels, logos,visual, messaging, tone, software, engineering, frontend, backend, design, development, craft, game, web, website, technology'); ?>
<?php $__env->startSection('canonical', 'https://webshoptechnology.com/bootcamp/payment'); ?>
<?php $__env->startSection('main'); ?>
<main>
 
        <section class="error__page">
          <div class="container line">
            <span class="line-3"></span>
            <div class="row">
              <div class="col-xxl-12">
                <div class="error__content">
                  <img src="<?php echo e(asset('assets/imgs/bootcamp/thanks.jpg')); ?>" alt="thank you so much">
                  <h3>Your payment has been confirmed and a receipt has been sent to your mail</h3>
                  <p>Your login detail has been sent to your registered email.</p>
                  <div class="btn_wrapper">
                    <a href="/" class="wc-btn-primary btn-hover btn-item"><span></span> Back to <br>Homepage <i
                        class="fa-solid fa-arrow-right"></i></a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section> 

      </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nzfdwqne/webshoptechnology.com/resources/views/bootcamp/thanks.blade.php ENDPATH**/ ?>