<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['cta']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['cta']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<div class="cta__area-4">
    <div class="container g-0 line_4 pb-150">
        <div class="line-col-4">
            <div></div>
            <div></div>
            <div></div>
            <div></div>
        </div>

        <div class="cta__inner-4">
            <div class="row">
                <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-4">
                    <div class="cta__content-4">
                        <img src="<?php echo e(asset('assets/imgs/thumb/4/1.png')); ?>" alt="Cta Image">
                    </div>
                </div>
                <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-4">
                    <div class="cta__content-4">
                        <h2 class="cta__title-4 title-anim">Let’s make someting great together</h2>
                    </div>
                </div>
                <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-4">
                    <div class="cta__content-4 text-anim">
                        <p>Using year-over-year most design approaches and latest techs website will be lightly.</p>
                        <a class="btn-started" href="<?php echo e(url('contact-us')); ?>">Get a Quote <span><i class="fa-solid fa-arrow-right"></i></span></a>
                    </div>
                </div>
            </div>

            <img src="<?php echo e(asset('assets/imgs/shape/21.png')); ?>" alt="shape Image" class="cta-shape">
            <img src="<?php echo e(asset('assets/imgs/shape/22.png')); ?>" alt="shape Image" class="cta-shape-2">
        </div>
    </div>
</div><?php /**PATH /home/nzfdwqne/webshoptechnology.com/resources/views/components/cta.blade.php ENDPATH**/ ?>