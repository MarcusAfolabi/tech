<?php $__env->startSection('title', 'Webshop Technology'); ?>
<?php $__env->startSection('description', 'Webshop Tech is a dynamic startup agency dedicated to providing cutting-edge web, mobile, and marketing services'); ?>
<?php $__env->startSection('keywords', 'webshop, software, engineering, frontend, backend, design, development, craft, game, web, website, technology'); ?>
<?php $__env->startSection('main'); ?>
<main>
    <div class="home-wrapper-4">

        <?php if (isset($component)) { $__componentOriginal04f02f1e0f152287a127192de01fe241 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal04f02f1e0f152287a127192de01fe241 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.hero','data' => [':hero' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('hero'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([':hero' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal04f02f1e0f152287a127192de01fe241)): ?>
<?php $attributes = $__attributesOriginal04f02f1e0f152287a127192de01fe241; ?>
<?php unset($__attributesOriginal04f02f1e0f152287a127192de01fe241); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal04f02f1e0f152287a127192de01fe241)): ?>
<?php $component = $__componentOriginal04f02f1e0f152287a127192de01fe241; ?>
<?php unset($__componentOriginal04f02f1e0f152287a127192de01fe241); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginalc54a9864f6b1015eca97122e9126ca0e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc54a9864f6b1015eca97122e9126ca0e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.workflow','data' => [':work' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('workflow'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([':work' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc54a9864f6b1015eca97122e9126ca0e)): ?>
<?php $attributes = $__attributesOriginalc54a9864f6b1015eca97122e9126ca0e; ?>
<?php unset($__attributesOriginalc54a9864f6b1015eca97122e9126ca0e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc54a9864f6b1015eca97122e9126ca0e)): ?>
<?php $component = $__componentOriginalc54a9864f6b1015eca97122e9126ca0e; ?>
<?php unset($__componentOriginalc54a9864f6b1015eca97122e9126ca0e); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginaldf187c71fc38a3841f2a07f6afcc91c7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldf187c71fc38a3841f2a07f6afcc91c7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.feature','data' => [':feat' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('feature'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([':feat' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldf187c71fc38a3841f2a07f6afcc91c7)): ?>
<?php $attributes = $__attributesOriginaldf187c71fc38a3841f2a07f6afcc91c7; ?>
<?php unset($__attributesOriginaldf187c71fc38a3841f2a07f6afcc91c7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldf187c71fc38a3841f2a07f6afcc91c7)): ?>
<?php $component = $__componentOriginaldf187c71fc38a3841f2a07f6afcc91c7; ?>
<?php unset($__componentOriginaldf187c71fc38a3841f2a07f6afcc91c7); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginal66548d68366ecf858f59644a73baefbe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal66548d68366ecf858f59644a73baefbe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.service','data' => [':service' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('service'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([':service' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal66548d68366ecf858f59644a73baefbe)): ?>
<?php $attributes = $__attributesOriginal66548d68366ecf858f59644a73baefbe; ?>
<?php unset($__attributesOriginal66548d68366ecf858f59644a73baefbe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal66548d68366ecf858f59644a73baefbe)): ?>
<?php $component = $__componentOriginal66548d68366ecf858f59644a73baefbe; ?>
<?php unset($__componentOriginal66548d68366ecf858f59644a73baefbe); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginale081b322cb04900d46907eb239a71a5b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale081b322cb04900d46907eb239a71a5b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.portfolio','data' => [':portfolio' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('portfolio'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([':portfolio' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale081b322cb04900d46907eb239a71a5b)): ?>
<?php $attributes = $__attributesOriginale081b322cb04900d46907eb239a71a5b; ?>
<?php unset($__attributesOriginale081b322cb04900d46907eb239a71a5b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale081b322cb04900d46907eb239a71a5b)): ?>
<?php $component = $__componentOriginale081b322cb04900d46907eb239a71a5b; ?>
<?php unset($__componentOriginale081b322cb04900d46907eb239a71a5b); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginala5c56c707c8c7f4c388a9c6c3095a9de = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala5c56c707c8c7f4c388a9c6c3095a9de = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.review','data' => [':review' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('review'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([':review' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala5c56c707c8c7f4c388a9c6c3095a9de)): ?>
<?php $attributes = $__attributesOriginala5c56c707c8c7f4c388a9c6c3095a9de; ?>
<?php unset($__attributesOriginala5c56c707c8c7f4c388a9c6c3095a9de); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala5c56c707c8c7f4c388a9c6c3095a9de)): ?>
<?php $component = $__componentOriginala5c56c707c8c7f4c388a9c6c3095a9de; ?>
<?php unset($__componentOriginala5c56c707c8c7f4c388a9c6c3095a9de); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginalf6134c4efa989c475ce128de8f91d695 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf6134c4efa989c475ce128de8f91d695 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.approach','data' => [':approach' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('approach'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([':approach' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf6134c4efa989c475ce128de8f91d695)): ?>
<?php $attributes = $__attributesOriginalf6134c4efa989c475ce128de8f91d695; ?>
<?php unset($__attributesOriginalf6134c4efa989c475ce128de8f91d695); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf6134c4efa989c475ce128de8f91d695)): ?>
<?php $component = $__componentOriginalf6134c4efa989c475ce128de8f91d695; ?>
<?php unset($__componentOriginalf6134c4efa989c475ce128de8f91d695); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginala649cfbd6b1ff6fb80672d9879217508 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala649cfbd6b1ff6fb80672d9879217508 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.cta','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('cta'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala649cfbd6b1ff6fb80672d9879217508)): ?>
<?php $attributes = $__attributesOriginala649cfbd6b1ff6fb80672d9879217508; ?>
<?php unset($__attributesOriginala649cfbd6b1ff6fb80672d9879217508); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala649cfbd6b1ff6fb80672d9879217508)): ?>
<?php $component = $__componentOriginala649cfbd6b1ff6fb80672d9879217508; ?>
<?php unset($__componentOriginala649cfbd6b1ff6fb80672d9879217508); ?>
<?php endif; ?>

    </div>
</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nzfdwqne/webshoptechnology.com/resources/views/welcome.blade.php ENDPATH**/ ?>