<section class="cta__area">
    <div class="container line pb-110 dark-p">
        <div class="line-3"></div>
        <div class="row">
            <div class="col-xxl-12">
                <div class="cta__content">
                    <p class="cta__sub-title">Work with us</p>
                    <h2 class="cta__title title-anim">We would love to hear more about your project</h2>
                    <div class="btn_wrapper">
                        <a href="{{ url('contact-us') }}" class="wc-btn-primary btn-hover btn-item"><span></span>Let’s talk us <i class="fa-solid fa-arrow-right"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>