@extends('layouts.main')
@section('title', 'Social Media Marketing SMM')
@section('description', "Designed to help businesses enhance their social media presence and reach a wider audience")
@section('keywords', 'seller, buyers, buy, sell, jiji, konga, jumia, vendor, shopify, wix, woocommerce, plugins, extension, team, extensive, experience, creating, high-quality, user-friendly, websites, mobile, mobile apps, apps, fiverr, upwork, brand, webshop, software, engineering, frontend, backend, design, development, craft, game, web, website, technology')
@section('canonical', 'https://webshoptechnology.com/services/social-media-marketing')
@section('main')
<main>
    <section class="development__area">
        <div class="container g-0 line pt-130 pb-150">
            <div class="line-3"></div>
            <div class="row">
                <div class="col-xxl-5 col-xl-5 col-lg-5 col-md-5">
                    <div class="sec-title-wrapper">
                        <h2 class="sec-title animation__char_come">Social Media Marketing (SMM)</h2>
                    </div>
                </div>
                <div class="col-xxl-7 col-xl-7 col-lg-7 col-md-7">
                    <div class="development__wrapper">
                        <div class="development__content">
                            <p>Designed to help businesses enhance their social media presence and </p>
                            <p>reach a wider audience</p>
                        </div>
                        <ul>
                            <li>+ Hootsuite</li>
                            <li>+ Buffer </li>
                            <li>+ Sprout Social</li>
                            <li>+ Adobe Creative Suite</li>
                            <li>+ Facebook Ads Manager</li>
                            <li>+ Google Ads</li>
                        </ul>
                    </div>
                </div>
                <div class="col-xxl-8 col-xl-8 col-lg-8 col-md-8">
                    <div class="development__img">
                        <img src="{{ asset('assets/imgs/thumb/dev-1.jpg') }}" alt="Development Image" data-speed="auto">
                    </div>
                </div>
                <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-4">
                    <div class="development__img">
                        <img src="{{ asset('assets/imgs/thumb/dev-2.jpg') }}" alt="Development Image">
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="workflow__area-6">
        <div class="container g-0 line pb-130">
            <div class="line-3"></div>
            <div class="workflow__wrapper-6">
                <div class="row">
                    <div class="col-xxl-3 col-xl-3 col-lg-3 col-md-3">
                        <div class="workflow__slide-6">
                            <h6 class="workflow__title-6">Performance Analysis and Reporting</h6>
                            <p>Webshop Tech provides regular analytics and reporting on the performance of the client's social media accounts and campaigns. This includes tracking key performance indicators (KPIs), such as engagement rates, follower growth, and website traffic, to ensure that the client's social media efforts are effective.
                            </p>
                        </div>
                    </div>

                    <div class="col-xxl-3 col-xl-3 col-lg-3 col-md-3">
                        <div class="workflow__slide-6">
                            <h6 class="workflow__title-6">Social Media Advertising</h6>
                            <p> Webshop Tech can create and manage social media advertising campaigns to promote the client's products or services to a wider audience. This includes targeting specific demographics, interests, and behaviors to ensure that the client's ads are seen by the right people.</p>
                        </div>
                    </div>

                    <div class="col-xxl-3 col-xl-3 col-lg-3 col-md-3">
                        <div class="workflow__slide-6">
                            <h6 class="workflow__title-6">Content Creation</h6>
                            <p>Webshop Tech creates high-quality social media content, including images, videos, and copy, that are tailored to the needs and interests of the client's target audience. We also optimize the content for different social media platforms to ensure maximum engagement and reach. </p>
                        </div>
                    </div>
                    <div class="col-xxl-3 col-xl-3 col-lg-3 col-md-3">
                        <div class="workflow__slide-6">
                            <h6 class="workflow__title-6">Social Media Strategy Development</h6>
                            <p>Webshop Tech works with clients to develop a customized social media strategy that aligns with their business goals, target audience, and industry. This includes identifying the right social media platforms to focus on and developing a content calendar to guide the creation and publishing of social media content.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="service__detail">
        <div class="container g-0 line pb-140">
            <div class="line-3"></div>
            <div class="row">
                <div class="col-xxl-12">
                    <div class="sec-title-wrapper">
                        <h2 class="sec-title title-anim">We team-up, we collaborate and solve problems together</h2>
                    </div>
                </div>
                <div class="col-xxl-3 col-xl-3 col-lg-3 col-md-3">
                    <div class="service__detail-circle">
                        <span></span>
                    </div>
                </div>
                <div class="col-xxl-9 col-xl-9 col-lg-9 col-md-9">
                    <div class="service__detail-img">
                        <img src="{{ asset('assets/imgs/thumb/service-detail.png') }}" alt="Service detail image">
                        <img src="{{ asset('assets/imgs/icon/shape-6.png') }}" alt="Service shape image" class="sd-shape">
                    </div>
                    <div class="service__detail-content">
                        <p> Our Social Media Marketing services are exceptional</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="faq__area">
        <div class="container g-0 line pb-140">
            <div class="line-3"></div>
            <div class="row">
                <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6">
                    <div class="faq__img">
                    <img src="{{ asset('assets/imgs/thumb/faq.png') }}" alt="FAQ Image" data-speed="auto">
                    </div>
                </div>
                <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6">
                    <div class="faq__content">
                        <h2 class="faq__title title-anim">Answers to possible questions</h2>

                        <div class="faq__list">
                            <div class="accordion" id="accordionExample">
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="headingOne">
                                        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                            What social media platforms will Webshop Tech use to promote my business? </button>
                                    </h2>
                                    <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                                        <div class="accordion-body">
                                            <p> We will use the social media platforms that are most relevant to your business and target audience. This can include Facebook, Instagram, Twitter, LinkedIn, Youtube, and others.</p>
                                        </div>
                                    </div>
                                </div>

                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="headingTwo">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                            How will you create content for my social media pages? </button>
                                    </h2>
                                    <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
                                        <div class="accordion-body">
                                            <p> We will work with you to develop a content strategy that aligns with your brand and goals. Our team of content creators will produce high-quality images, videos, and copy that are engaging and relevant to your audience.

                                            </p>
                                        </div>
                                    </div>
                                </div>

                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="headingThree">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                            How will you measure the success of our social media marketing efforts? </button>
                                    </h2>
                                    <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionExample">
                                        <div class="accordion-body">
                                            <p> We use a range of analytics tools to track the performance of your social media pages and campaigns. This includes metrics such as reach, engagement, click-through rates, and conversions.

                                            </p>
                                        </div>
                                    </div>
                                </div>

                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="headingFour">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                            How often will you post on my social media pages? </button>
                                    </h2>
                                    <div id="collapseFour" class="accordion-collapse collapse" aria-labelledby="headingFour" data-bs-parent="#accordionExample">
                                        <div class="accordion-body">
                                            <p> We will develop a posting schedule that aligns with your content strategy and goals. This can include daily, weekly, or monthly posts depending on the needs of your business.

                                            </p>
                                        </div>
                                    </div>
                                </div>

                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="headingFive">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
                                            Can you help me run social media advertising campaigns? </button>
                                    </h2>
                                    <div id="collapseFive" class="accordion-collapse collapse" aria-labelledby="headingFive" data-bs-parent="#accordionExample">
                                        <div class="accordion-body">
                                            <p> Yes, we can help you run social media advertising campaigns on platforms such as Facebook, Instagram, and LinkedIn. Our team will work with you to develop ad creatives, target the right audience, and optimize your campaigns for maximum ROI.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- FAQ area end -->

    <x-cta2 />
</main>

@endsection